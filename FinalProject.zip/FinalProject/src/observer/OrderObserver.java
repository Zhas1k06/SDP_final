package observer;

public interface OrderObserver {
    void update(String status);
}