package decorator;

public interface FoodItem {
    String getDescription();
    double getPrice();
}