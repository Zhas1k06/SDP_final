package adapter;

public class LegacyFoodOrderSystem {
    public void placeOrder(String foodItem, int quantity) {
        // Реализация размещения заказа в существующей системе.
    }

    public void registerCustomer(String customerName) {
        // Реализация регистрации нового клиента.
    }
}