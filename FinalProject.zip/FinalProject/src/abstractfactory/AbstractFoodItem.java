package abstractfactory;

public interface AbstractFoodItem {
    String getDescription();
    double getPrice();
}