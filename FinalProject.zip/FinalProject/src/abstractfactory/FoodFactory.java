package abstractfactory;
public interface FoodFactory {
    AbstractFoodItem createFoodItem();
}