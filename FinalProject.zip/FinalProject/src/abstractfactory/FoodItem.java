package abstractfactory;

public interface FoodItem {
    String getDescription();
    double getPrice();
}